package com.istoic.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
